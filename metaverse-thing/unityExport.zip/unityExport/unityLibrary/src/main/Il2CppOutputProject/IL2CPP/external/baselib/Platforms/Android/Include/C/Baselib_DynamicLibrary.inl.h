#pragma once

typedef enum Baselib_DynamicLibrary_NativeHandleType
{
    Baselib_DynamicLibrary_PosixDlopen = 1,
} Baselib_DynamicLibrary_NativeHandleType;
