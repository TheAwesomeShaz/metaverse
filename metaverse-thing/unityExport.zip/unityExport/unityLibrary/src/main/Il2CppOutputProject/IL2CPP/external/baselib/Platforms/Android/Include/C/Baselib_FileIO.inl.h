#pragma once

typedef enum Baselib_FileIO_NativeHandleType
{
    Baselib_FileIO_NativeHandleType_PosixFd = 1,
} Baselib_FileIO_NativeHandleType;
